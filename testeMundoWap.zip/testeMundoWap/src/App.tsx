import React, { useEffect, useReducer, useState } from "react";
import Header from "./components/Header";
import tasksReducer from "./reducers/TaskReducer";
import { ITask } from "./utils/interfaces/Task";
import { addTask, getPaginatedTasks, updateTask } from "./api/TaskAPI";
import { TaskActions } from "./actions/TaskActions";
import { IPagination } from "./utils/interfaces/Pagination";
import { Paginator } from "./components/Paginator";
import { TaskList } from "./components/TaskList";
import styled from "styled-components";
import Modal from "./components/Modal";

const INITIAL_STATE: IPagination<ITask> = {
  page: 1,
  totalPages: 1,
  total: 0,
  limit: 10,
  data: [],
};

function App() {
  const LIMIT = 10;
  const [paginatedTasks, dispatch] = useReducer(tasksReducer, INITIAL_STATE);
  const [description, setDescription] = useState("");
  const [loading, setLoading] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    setLoading(true);
    getPaginatedTasks(paginatedTasks.page, LIMIT).then(
      (paginatedTasksResult: IPagination<ITask>) => {
        dispatch({
          type: TaskActions.FETCHED_TASKS,
          data: paginatedTasksResult,
        });
        setLoading(false);
      },
    );
  }, [paginatedTasks.page]);

  const handlePageChange = (page: number) => {
    if (page < 1 || page > paginatedTasks.totalPages) return;

    dispatch({
      type: TaskActions.PAGE_CHANGED,
      page,
    });
  };

  const handleCreateNewTask = () => {
    if (!description) return; // TODO: Show error message

    setLoading(true);
    setDescription("");

    addTask(description).then((task: ITask) => {
      dispatch({
        type: TaskActions.TASK_CREATED,
        task,
      });
      setLoading(false);
    });
  };

  const handleEditTask = (task: ITask) => {
    setLoading(true);
    updateTask(task).then((task: ITask) => {
      dispatch({
        type: TaskActions.TASK_UPDATED,
        task,
      });
      setLoading(false);
    });
  };

  const toggleModal = () => {
    setIsModalOpen(!isModalOpen);
  };

  return (
    <>
      <Header taskCount={paginatedTasks.total} />
      <Modal isOpen={isModalOpen} onClose={toggleModal} />
      <AppContainer>
        <InputContainer>
          <input
            type="text"
            placeholder="Description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
          />
          <button onClick={() => handleCreateNewTask()} disabled={loading}>
            Create
          </button>
        </InputContainer>
        {loading ? (
          <span>Loading...</span>
        ) : (
          <TaskList tasks={paginatedTasks.data} editTask={handleEditTask} />
        )}
        <Paginator
          currentPage={paginatedTasks.page}
          changePage={handlePageChange}
          disabled={loading}
        />
      </AppContainer>
    </>
  );
}

const AppContainer = styled.div`
  margin: 20px;
`;

const InputContainer = styled.div`
  margin-bottom: 10px;
`;

export default App;
