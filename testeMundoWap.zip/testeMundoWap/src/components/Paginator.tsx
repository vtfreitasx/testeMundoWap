import styled from "styled-components";

interface PaginatorProps {
  currentPage: number;
  changePage: (page: number) => void;
  disabled?: boolean;
}

export const Paginator = ({
  currentPage,
  changePage,
  disabled,
}: PaginatorProps) => {
  return (
    <PaginatorContainer className="paginator">
      <button onClick={() => changePage(currentPage - 1)} disabled={disabled}>
        Prev
      </button>
      <span>{currentPage}</span>
      <button onClick={() => changePage(currentPage + 1)} disabled={disabled}>
        Next
      </button>
    </PaginatorContainer>
  );
};

const PaginatorContainer = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  margin-top: 20px;

  button {
    margin: 0 10px;
    padding: 10px 15px;
    border: none;
    border-radius: 5px;
    background-color: #ccc;
    color: #fff;
    cursor: pointer;
  }

  span {
    margin: 0 10px;
  }
`;
