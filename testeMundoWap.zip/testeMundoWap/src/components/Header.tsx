import React from "react";
import styled from "styled-components";

interface HeaderProps {
  taskCount: number;
}

const Header: React.FC<HeaderProps> = ({ taskCount }) => {
  const getHeaderColor = () => {
    if (taskCount <= 3) {
      return "green";
    } else if (taskCount >= 10) {
      return "red";
    } else {
      return "blue";
    }
  };

  return (
    <HeaderContainer color={getHeaderColor()}>
      <TaskCounter>{taskCount} {taskCount === 1 ? 'task' : 'tasks'} pending</TaskCounter>
      <CreateTaskButton>Open Modal</CreateTaskButton>
    </HeaderContainer>
  );
};

const HeaderContainer = styled.div<{ color: string }>`
  background-color: ${(props) => props.color};
  padding: 10px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  color: white;
  box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
`;

const TaskCounter = styled.span`
  font-size: 16px;
`;

const CreateTaskButton = styled.button`
  background-color: #007bff;
  color: white;
  padding: 8px 12px;
  cursor: pointer;
  border: none;
  border-radius: 5px;
`;

export default Header;
