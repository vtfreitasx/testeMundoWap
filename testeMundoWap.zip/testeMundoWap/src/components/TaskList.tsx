import styled from "styled-components";
import { ITask } from "../utils/interfaces/Task";
import { TaskItem } from "./TaskItem";

interface TaskListProps {
  tasks: ITask[];
  editTask: (task: ITask) => void;
}
export const TaskList = ({ tasks, editTask }: TaskListProps) => {
  return (
    <TaskListContainer className="task-list">
      {tasks.map((task) => (
        <TaskItem task={task} key={task.id} save={editTask} />
      ))}
    </TaskListContainer>
  );
};

const TaskListContainer = styled.div`
  display: flex;
  flex-direction: column;
  margin-top: 20px;
`;
