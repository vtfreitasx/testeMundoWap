import { useState } from "react";
import styled from "styled-components";
import { ITask } from "../utils/interfaces/Task";

interface TaskItemProps {
  task: ITask;
  save: (task: ITask) => void;
}

export const TaskItem = ({ task, save }: TaskItemProps) => {
  const [editTask, setEditTask] = useState(false);
  const [description, setDescription] = useState(task.description);

  const saveTask = () => {
    if (!description) return; // TODO: Show error message

    setEditTask(false);
    task.description = description;
    save(task);
  };

  return (
    <TaskItemContainer>
      <input type="checkbox" />
      <TaskItemDescription
        type="text"
        value={description}
        disabled={!editTask}
        onChange={(e) => setDescription(e.target.value)}
      />
      {!editTask ? (
        <button onClick={() => setEditTask(true)}>Edit</button>
      ) : (
        <button onClick={() => saveTask()}>Save</button>
      )}
    </TaskItemContainer>
  );
};

const TaskItemContainer = styled.div`
    display: flex;
    align-items: center;
    margin-bottom: 10px;

    input {
      margin-right: 10px;
`;

const TaskItemDescription = styled.input<{ disabled?: boolean }>`
  border: none;
  background-color: transparent;
  border-bottom: 1px solid #ccc;
  padding: 5px;
  margin-right: 10px;
  width: 100%;
  font-size: 16px;

  &:disabled {
    border-bottom: none;
  }
`;
