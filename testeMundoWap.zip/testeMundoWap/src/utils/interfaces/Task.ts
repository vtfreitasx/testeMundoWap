export interface ITask {
  id: number;
  description: string;
  completed: boolean;
  createdAt: Date;
  updatedAt: Date;
}
